// Evaluation only: reuse the existing C ABI and Graph's public edge properties.
#include "bridge.h"
#include "lib/Graph.h"
#include <boost/graph/graph_traits.hpp>
#include <chrono>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <cstdlib>

int main(int argc, char **argv) {
 try {
  if(argc!=5) throw std::runtime_error("graph, source, target, factor required");
  std::ifstream file(argv[1]);std::stringstream buffer;buffer<<file.rdbuf();auto text=buffer.str();
  int source=std::stoi(argv[2]),target=std::stoi(argv[3]);float factor=std::stof(argv[4]);
  bridge_cowl_init();void *manager=bridge_cowl_manager();
  void *onto=bridge_load_ontology(manager,"/chaincode/onto/client_final_ontology.owl");
  if(!onto) throw std::runtime_error("ontology load failed");
  void *handle=graph_new();graph_init_reasoner(handle,onto);graph_create_from_json(handle,text.c_str(),onto,0);
  auto *graph=static_cast<Graph*>(handle);json changes=json::array();
  if(source>=0){
   auto range=boost::edges(graph->rank_data.g);bool found=false;
   for(auto it=range.first;it!=range.second;++it){
    if(static_cast<int>(boost::source(*it,graph->rank_data.g))!=source || static_cast<int>(boost::target(*it,graph->rank_data.g))!=target)continue;
    float before=boost::get(boost::edge_weight,graph->rank_data.g,*it);float after=before*factor;
    if(after < -1 || after > 1)throw std::runtime_error("intervention out of bounds");
    boost::put(boost::edge_weight,graph->rank_data.g,*it,after);
    Graph::Vertex s=source,t=target;float readback=graph->retriveWeight(s,t);
    if(readback!=after)throw std::runtime_error("native getter does not observe modified edge");
    changes.push_back({{"source",source},{"target",target},{"before",before},{"after",after}});found=true;
   }
   if(!found)throw std::runtime_error("declared edge not found");
  }
  auto started=std::chrono::steady_clock::now();graph_compute_rank(handle);
  auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
  char *raw=graph_get_result_json(handle);if(!raw)throw std::runtime_error("missing result");
  json output=json::parse(raw);std::free(raw);
  for(const auto &change:changes){bool checked=false;for(const auto &edge:output["graph"]["edges"]){auto d=edge["data"];if(d["source"]==change["source"] && d["target"]==change["target"]){if(d["label"].get<float>()!=change["after"].get<float>())throw std::runtime_error("reported weight differs from intervention");checked=true;}}if(!checked)throw std::runtime_error("edge absent from output");}
  std::cout<<"EVALUATION_RESULT:"<<json({{"changes",changes},{"native",output},{"compute_seconds",elapsed}}).dump()<<std::endl;
  graph_delete(handle);bridge_cowl_release(onto);bridge_cowl_release(manager);return 0;
 }catch(const std::exception &e){std::cerr<<"EVALUATION_ERROR:"<<e.what()<<std::endl;return 1;}
}
