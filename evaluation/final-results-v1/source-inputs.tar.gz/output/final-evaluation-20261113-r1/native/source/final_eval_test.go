package main

// Local execution of the identical RankGraph implementation. Only state storage
// uses MockStub; the OWL reasoner, native library, association and encoding are real.
import("encoding/json";"os";"testing";"time";"reflect";"fmt";"github.com/hyperledger/fabric-chaincode-go/shimtest";"github.com/hyperledger/fabric-contract-api-go/contractapi")
func TestFinalEvaluationOffchain(t *testing.T){
 data,err:=os.ReadFile("/eval/offchain-plan.json");if err!=nil{t.Fatal(err)}
 var plan []struct{ID string `json:"id"`;Key string `json:"key"`;Graph json.RawMessage `json:"graph"`;ExpectedRank json.RawMessage `json:"expected_rank"`;ExpectedAnnotated json.RawMessage `json:"expected_annotated"`;ExpectedNative string `json:"expected_native"`}
 if err=json.Unmarshal(data,&plan);err!=nil{t.Fatal(err)}
 results:=[]map[string]interface{}{}
 for _,trial:=range plan{
  stub:=shimtest.NewMockStub("offchain",nil);ctx:=new(contractapi.TransactionContext);ctx.SetStub(stub);contract:=new(ArgumentationContract)
  stub.MockTransactionStart("store");started:=time.Now();_,err=contract.StoreGraph(ctx,trial.Key,string(trial.Graph));store:=time.Since(started).Seconds();stub.MockTransactionEnd("store");if err!=nil{t.Fatal(err)}
  stub.MockTransactionStart("rank");started=time.Now();_,err=contract.RankGraph(ctx,trial.Key);rank:=time.Since(started).Seconds();stub.MockTransactionEnd("rank");if err!=nil{t.Fatal(err)}
  for suffix,expected:=range map[string]json.RawMessage{"_rank":trial.ExpectedRank,"_annotated_graph":trial.ExpectedAnnotated}{raw,e:=stub.GetState(trial.Key+suffix);if e!=nil{t.Fatal(e)};var a,b interface{};if json.Unmarshal(raw,&a)!=nil||json.Unmarshal(expected,&b)!=nil||!reflect.DeepEqual(a,b){t.Fatal("native outputs differ from onchain",trial.ID,suffix)}}
  raw,_:=stub.GetState(trial.Key+"_native_output");if string(raw)!=trial.ExpectedNative{t.Fatal("raw native output differs",trial.ID)}
  results=append(results,map[string]interface{}{"id":trial.ID,"store_seconds":store,"rank_seconds":rank,"raw_native_and_adapted_outputs_equal":true})
  fmt.Println("OFFCHAIN_TRIAL",trial.ID,rank)
 }
 out,err:=json.MarshalIndent(results,"","  ");if err!=nil{t.Fatal(err)};if err=os.WriteFile("/results/offchain-results.json",out,0644);err!=nil{t.Fatal(err)}
}
