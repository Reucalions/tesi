"""Use the existing Fablo REST API; tokens remain in memory and are never archived."""
from pathlib import Path
import json,time,urllib.request,urllib.error
from dotenv import dotenv_values
BRIDGE=Path('/Users/reucalion/Desktop/agent-based-cti-argumentation-pipeline/mcp-fablo-server')
class Rest:
 def __init__(self):
  env=dotenv_values(BRIDGE/'.env');body=json.dumps({'id':env['FABLO_USER'],'secret':env['FABLO_PASSWORD']}).encode()
  req=urllib.request.Request('http://127.0.0.1:8800/user/enroll',data=body,headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=60) as reply:self.token=json.load(reply)['token']
 def call(self,kind,chaincode,method,args,transient=None):
  body={'method':method,'args':args}
  if transient is not None:body['transient']=transient
  route=f'/{kind}/my-channel/{chaincode}'
  request=urllib.request.Request('http://127.0.0.1:8800'+route,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+self.token})
  started=time.perf_counter()
  try:
   with urllib.request.urlopen(request,timeout=180) as reply:raw=reply.read();status=reply.status
  except urllib.error.HTTPError as exc:raise RuntimeError(f'{route} HTTP {exc.code}') from None
  elapsed=time.perf_counter()-started
  return json.loads(raw),{'path':route,'method':method,'elapsed_seconds':elapsed,'status':status}
