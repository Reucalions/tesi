from pathlib import Path
import base64,hashlib,json,re
from rest_client import Rest
OUT=Path(__file__).resolve().parent;TARGET=OUT/'semantic';TARGET.mkdir(exist_ok=False)
ROOT=OUT.parent.parent
logback=ROOT/'output/case-improvements-20261106/semantics/deployed_ontology.owl'
baseline=Path('/Users/reucalion/Desktop/semantic-cti-ledger-argumentation/chaincode-argumentation/onto/client_final_ontology.owl')
deployment=json.loads((ROOT/'output/case-improvements-20261106/semantics/deployment-r2/deployment.json').read_text())
prefix=re.search(r'Prefix\(:=<([^>]+)>\)',baseline.read_text()).group(1)
queries=[{'id':'logback-abduction-bonus','ontology':str(logback),'resource':deployment['resource_iri'],'request':deployment['request_iri'],'abduction':True,'bonus':True,'contraction':False,'expected':'Existing C1 pair; abduction should reproduce 38. Bonus is explicitly invoked, not inferred from an empty domain field.'},{'id':'baseline-direct-clash','ontology':str(baseline),'resource':prefix+'AutomatedCountermeasure','request':prefix+'AIBasedCountermeasure','abduction':False,'bonus':False,'contraction':True,'expected':'Explicit DisjointClasses(AIBasedCountermeasure AutomatedCountermeasure); positive contraction expected without inventing an action profile.'}]
protocol={'date':'2026-11-13','queries':queries,'repetitions':3,'method':'Existing user-registry AnalyzeOntology through REST query/evaluate with transient existing OWL; no new ontology persisted or product/MCP tool introduced. Native reasoning diagnostic, not a new full-pipeline accepted/fallback case.','source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [logback,baseline]},'false_flags':'Operation not requested, not a measured zero.','numeric_oracle_bonus':None}
(TARGET/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
client=Rest();results=[]
for repetition in range(1,4):
 for query in queries:
  args=['evaluation-'+query['id'],query['resource'],query['request'],str(query['abduction']).lower(),str(query['bonus']).lower(),str(query['contraction']).lower()]
  response,event=client.call('query','user-registry','AnalyzeOntology',args,{'ontology':base64.b64encode(Path(query['ontology']).read_bytes()).decode()})
  row={'case':query['id'],'repetition':repetition,'event':event,'response':response}
  (TARGET/f"{query['id']}-r{repetition}.json").write_text(json.dumps(row,indent=2)+'\n');results.append(row)
  print('semantic',query['id'],repetition,list(response.get('response',{})),flush=True)
(TARGET/'results.json').write_text(json.dumps(results,indent=2)+'\n')
