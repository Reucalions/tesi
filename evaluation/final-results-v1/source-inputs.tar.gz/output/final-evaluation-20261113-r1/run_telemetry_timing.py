"""Time the unchanged CAMEL Telemetry worker with its real OTel gateway.

No Workforce managers or downstream agents are run; this is a component timer,
not another full end-to-end execution or a new precision/recall sample.
"""
from pathlib import Path
import json,os,sys,threading,time,urllib.request
from http.server import ThreadingHTTPServer
ROOT=Path('/Users/reucalion/tesi');sys.path.insert(0,str(ROOT))
OUT=Path(__file__).resolve().parent;TARGET=OUT/'telemetry-worker';TARGET.mkdir(exist_ok=False)
from camel.messages import BaseMessage
from services.otel_gateway.server import handler_for
from thesis_agents.agents import telemetry
from thesis_agents.agents.contracts import AGENT_CONTRACTS
from thesis_agents.backends import RunAudit
from thesis_agents.config import ModelSettings
from thesis_agents.orchestration.artifacts import ArtifactSession
from thesis_agents.orchestration.chat_agent import ArtifactChatAgent
from thesis_agents.orchestration.publication_tools import PublicationTools
from thesis_agents.orchestration.workforce import COMMON
from thesis_agents.schemas.telemetry import RuntimeEvidence
from thesis_agents.schemas.telemetry_source import TelemetryInput
from thesis_agents.telemetry.settings import TelemetryHTTPSettings
from thesis_agents.tools.telemetry_http import HTTPTelemetryTool
BASE=ROOT/'output/case-improvements-20261106/sources/vulnerable'
case=TelemetryInput.model_validate_json((BASE/'input.json').read_bytes())
os.environ.update(LLM_MODEL='tesi-apache-qwen3:4b-32k',LLM_API_KEY='local',LLM_BASE_URL='http://127.0.0.1:11434/v1',LLM_CONTEXT_TOKENS='32768',LLM_MAX_TOKENS='4096',LLM_TEMPERATURE='0',LLM_TIMEOUT_SECONDS='600',CAMEL_MODEL_LOG_ENABLED='true')
with urllib.request.urlopen('http://127.0.0.1:11434/api/tags',timeout=10) as response:tags=json.load(response)
model=next(x for x in tags['models'] if x['name']==os.environ['LLM_MODEL'])
protocol={'date':'2026-11-13','repetitions':3,'model':{'name':model['name'],'digest':model['digest'],'context':32768,'max_output_tokens':4096,'temperature':0,'timeout_seconds':600},'worker':'Existing ArtifactChatAgent, COMMON + telemetry.OTEL_PROMPT, PublicationTools.resolve, same three production tools and original settings from workforce.py.','timer':'perf_counter around worker.step only; includes model/tool calls and publication, excludes model object construction and Workforce management. OTel gateway read is separately timed by the existing tool. First model loading cost is included if incurred.','source':'Existing SDK file replay from 6 November; no fresh application event and no real-time latency claim.','llm_used':True,'new_precision_recall_scoring':False,'full_pipeline':False,'warmup_excluded':0}
(TARGET/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
server=ThreadingHTTPServer(('127.0.0.1',0),handler_for(BASE/'otel.jsonl','logback-C1-otel','sdk-file'));threading.Thread(target=server.serve_forever,daemon=True).start()
results=[]
try:
 for rep in range(1,4):
  directory=TARGET/f'r{rep}';session=ArtifactSession(case,directory,mode='camel',model=os.environ['LLM_MODEL'])
  os.environ['CAMEL_LOG_DIR']=str(directory/'llm')
  profile=TelemetryHTTPSettings.model_validate({'transport':'http','url':f'http://127.0.0.1:{server.server_port}/v1/observations','source_id':'logback-C1-otel','acquisition':'sdk-file'})
  session.telemetry_tool=HTTPTelemetryTool(profile,RunAudit(directory/'telemetry-events.jsonl',session.run_id))
  publications=PublicationTools(session);settings=ModelSettings.from_env()
  agent=ArtifactChatAgent(system_message=BaseMessage.make_assistant_message(role_name='TelemetryAgent',content=COMMON+'\n'+telemetry.OTEL_PROMPT),model=settings.create_backend(),tools=[publications.resolve(name) for name in telemetry.TOOLS],max_iteration=20,retry_attempts=1,step_timeout=300)
  started=time.perf_counter();row={'repetition':rep,'run_id':session.run_id,'success':False}
  try:
   reply=agent.step(BaseMessage.make_user_message(role_name='Operator',content=AGENT_CONTRACTS[0].task))
   row['elapsed_seconds']=time.perf_counter()-started
   evidence=RuntimeEvidence.model_validate_json((directory/'runtime_evidence.json').read_bytes())
   acquired=session.collect_runtime_evidence();assert evidence.model_dump(mode='json')==acquired
   row.update(success=True,evidence=evidence.model_dump(mode='json'),agent_messages=[m.content for m in reply.msgs])
  except Exception as exc:row.update(elapsed_seconds=time.perf_counter()-started,error_type=type(exc).__name__,error=str(exc)[:1000])
  (directory/'measurement.json').write_text(json.dumps(row,indent=2)+'\n');results.append(row);print('telemetry worker',rep,row['success'],row['elapsed_seconds'],flush=True)
finally:server.shutdown();server.server_close()
(TARGET/'results.json').write_text(json.dumps(results,indent=2)+'\n')
