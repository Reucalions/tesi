"""Existing baseline semantic controls, explicitly separate from application C1/C4.

The available AI individual is also used as the request in the positive control:
this tests reflexivity, not the applicability of a new remediation to an asset.
"""
import asyncio,base64,hashlib,json,os,re
from pathlib import Path
from datetime import timedelta
from rest_client import Rest
from dotenv import dotenv_values
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent.parent;TARGET=OUT/'semantic-controls';TARGET.mkdir(exist_ok=False)
LEDGER=Path('/Users/reucalion/Desktop/semantic-cti-ledger-argumentation');BRIDGE=Path('/Users/reucalion/Desktop/agent-based-cti-argumentation-pipeline/mcp-fablo-server')
source=LEDGER/'chaincode-argumentation/onto/client_final_ontology.owl';raw=source.read_bytes();digest=hashlib.sha256(raw).hexdigest();prefix=re.search(r'Prefix\(:=<([^>]+)>\)',raw.decode()).group(1)
key='evaluation-baseline-semantics-20261113-'+digest[:12]
protocol={'date':'2026-11-13','ontology_key':key,'source':str(source),'ontology_sha256':digest,'resource_iri':prefix+'AIBasedCountermeasure','cases':['baseline-2-original-r1','baseline-1-original-r1'],'expected':'Baseline-2 top AI is a reflexive semantic acceptance control. Baseline-1 top Automated conflicts with AI by explicit DisjointClasses, then validation continues through the existing ranking.','scope':'Real persisted native rankings plus real semantic MCP validation. No operational context or action feasibility is asserted; no full MAS recommendation/finalization or actuator execution for these controls.','selection_analysis':'First semantic accepted candidate in native descending-score order, retained as an evaluation observation rather than an operational final decision.','product_source_changed':False}
(TARGET/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
rest=Rest();response,event=rest.call('invoke','user-registry','StoreTBoxTest',[key,base64.b64encode(raw).decode()]);(TARGET/'ontology-registration.json').write_text(json.dumps({'event':event,'response':response},indent=2)+'\n')

async def run():
 profile=json.loads((ROOT/'output/real-cases-20261105-r1/mcp-profile.json').read_text())['connection'];env=os.environ.copy();env.update({k:v for k,v in dotenv_values(BRIDGE/'.env').items() if v is not None});env.update(FABLO_REST_URL='http://127.0.0.1:8800',FABLO_INVOKE_PATH='/invoke/{channel}/{chaincode}',FABLO_QUERY_PATH='/query/{channel}/{chaincode}')
 params=StdioServerParameters(command=profile['command'],args=profile['args'],cwd=profile['cwd'],env=env);results=[]
 with (TARGET/'bridge.stderr.log').open('x') as stderr:
  async with stdio_client(params,errlog=stderr) as (r,w):
   async with ClientSession(r,w,read_timeout_seconds=timedelta(seconds=180)) as session:
    await session.initialize()
    async def call(name,args,path):
     reply=await session.call_tool(name,args);raw=reply.model_dump(mode='json');path.write_text(json.dumps(raw,indent=2)+'\n');envelope=json.loads(next(c.text for c in reply.content if c.type=='text'));assert not reply.isError and envelope['ok'],envelope;return envelope['payload']
    old=json.loads((ROOT/'output/native-explanation-benchmark-20261113-r1/protocol.json').read_text())['trials']
    for case in protocol['cases']:
     trial=next(t for t in old if t['id']==case);body=await call('get_rank_result',{'graph_id':trial['graph_id']},TARGET/(case+'-ranking.json'));ranking=json.loads(body['response']['success']);ordered=sorted(ranking,key=lambda r:(-r['score'],r['name']));attempts=[]
     for row in ordered:
      validation=await call('validate_countermeasure',{'asset_iri':protocol['resource_iri'],'countermeasure_iri':prefix+row['name'],'ontology_id':key},TARGET/(case+'-'+row['name']+'.json'))
      attempts.append({'candidate':row['name'],'score':row['score'],'semantic_status':validation['status'],'native':validation['reasoning']['native']})
      if validation['status']=='accepted':break
     results.append({'case':case,'native_graph_key':trial['graph_id'],'ordered_ranking':ordered,'semantic_attempts':attempts,'first_semantic_accepted':next((a['candidate'] for a in attempts if a['semantic_status']=='accepted'),None),'application_acceptance_claimed':False})
     print(case,[(a['candidate'],a['semantic_status']) for a in attempts],flush=True)
 (TARGET/'results.json').write_text(json.dumps(results,indent=2)+'\n')
asyncio.run(run())
