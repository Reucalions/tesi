from pathlib import Path
import asyncio,hashlib,json,os,shutil
from datetime import timedelta
from dotenv import dotenv_values
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
ROOT=Path('/Users/reucalion/tesi');OUT=Path(__file__).resolve().parent;TARGET=OUT/'readbacks';TARGET.mkdir(exist_ok=False)
BRIDGE=Path('/Users/reucalion/Desktop/agent-based-cti-argumentation-pipeline/mcp-fablo-server');STORE=Path('/Users/reucalion/Desktop/semantic-cti-ledger-argumentation/fablo-rest/data/decisions')
sources={'C1':ROOT/'output/case-improvements-20261106/runs/C1-r2/finalization/native_strategic_finalization.json','C4-r2':ROOT/'output/c4-collaudo-20261112-r1/continuation-r1/finalization/native_strategic_finalization.json','C4-r3':ROOT/'output/case-improvements-20261106/runs/C4-r3/finalization/native_strategic_finalization.json',**{arm:OUT/'ablation-r2'/arm/'finalization/native_strategic_finalization.json' for arm in ['with-runtime','without-runtime']}}
async def main():
 env=os.environ.copy();env.update({k:v for k,v in dotenv_values(BRIDGE/'.env').items() if v is not None});env.update(FABLO_REST_URL='http://127.0.0.1:8800',FABLO_INVOKE_PATH='/invoke/{channel}/{chaincode}',FABLO_QUERY_PATH='/query/{channel}/{chaincode}')
 config=json.loads((ROOT/'output/real-cases-20261105-r1/mcp-profile.json').read_text())['connection'];parameters=StdioServerParameters(command=config['command'],args=config['args'],cwd=config['cwd'],env=env);proofs={};backups={}
 with (TARGET/'bridge.stderr.log').open('x') as stderr:
  async with stdio_client(parameters,errlog=stderr) as (r,w):
   async with ClientSession(r,w,read_timeout_seconds=timedelta(seconds=180)) as session:
    await session.initialize()
    for name,path in sources.items():
     original=json.loads(path.read_text())['results'][0];doc=json.loads(original['record']['document_json']);decision=doc['ranking_decision_id']
     reply=await session.call_tool('get_finalization',{'decision_id':decision,'finalization_id':original['record']['finalization_id']});raw=reply.model_dump(mode='json');(TARGET/(name+'.json')).write_text(json.dumps(raw,indent=2)+'\n');value=json.loads(next(c.text for c in reply.content if c.type=='text'));assert not reply.isError and value['ok'] and value['payload']==original
     assert original['commit']['successful'] and original['commit']['validation_code']==0 and original['ledger_readback_verified']
     proofs[name]={'record_provenance_receipt_identical':True,'transaction_id':original['commit']['transaction_id'],'block_number':original['commit']['block_number'],'source':str(path),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
     if name in ['with-runtime','without-runtime']:
      evid=STORE/'backend-evidence'/hashlib.sha256(decision.encode()).hexdigest();files=[STORE/(decision+'.json')]+[p for p in evid.rglob('*') if p.is_file()];assert len(files)>=3
      for p in files:
       rel=p.relative_to(STORE);target=OUT/'saas-metadata'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);digest=hashlib.sha256(p.read_bytes()).hexdigest();assert hashlib.sha256(target.read_bytes()).hexdigest()==digest;backups[str(rel)]=digest
 (TARGET/'verification.json').write_text(json.dumps(proofs,indent=2)+'\n');(OUT/'saas-metadata-manifest.json').write_text(json.dumps({'source_root':str(STORE),'files_sha256':backups},indent=2)+'\n');print('Fresh readbacks',len(proofs),'backed up metadata',len(backups))
asyncio.run(main())
