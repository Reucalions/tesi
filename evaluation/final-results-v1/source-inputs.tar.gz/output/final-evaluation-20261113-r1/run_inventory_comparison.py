"""Frozen SBOM inventory versus the positively observed subset of that inventory.

Absence from this export never means software did not execute or is safe.
The static inventory scan is an evaluation baseline using the existing CTI tool,
not a newly implemented real-mode source pipeline.
"""
from pathlib import Path
import hashlib,json,sys
from pydantic import TypeAdapter
ROOT=Path('/Users/reucalion/tesi');sys.path.insert(0,str(ROOT));OUT=Path(__file__).resolve().parent;TARGET=OUT/'runtime-inventory';TARGET.mkdir(exist_ok=False)
from services.otel_gateway.server import identify
from thesis_agents.backends import RunAudit
from thesis_agents.mcp.client import MCPClient
from thesis_agents.mcp.settings import MCPConnectionSettings
from thesis_agents.schemas.telemetry import SoftwareObservation
from thesis_agents.tools.cti_mcp import CTIVulnerabilityTool,cti_contracts
BASE=ROOT/'output/case-improvements-20261106';sources=BASE/'sources/vulnerable';sbom=json.loads((sources/'sbom.cdx.json').read_text());observed=set()
for line in (sources/'otel.jsonl').read_text().splitlines():
 for group in json.loads(line).get('resourceLogs',[]):
  for scope in group.get('scopeLogs',[]):
   for record in scope.get('logRecords',[]):
    item=identify(group['resource'],record)
    if item:observed.add((item['package'],item['version']))
components=[c for c in sbom['components'] if c.get('name') and c.get('version')]
linked=[c for c in components if (c['name'],c['version']) in observed]
protocol={'date':'2026-11-13','sbom_sha256':hashlib.sha256((sources/'sbom.cdx.json').read_bytes()).hexdigest(),'otel_sha256':hashlib.sha256((sources/'otel.jsonl').read_bytes()).hexdigest(),'sbom_components':len(components),'runtime_observed':sorted(observed),'runtime_linked_components':len(linked),'with_runtime_policy':'Assess the positively observed intersection with the unchanged SBOM inventory.','without_runtime_policy':'Assess all explicitly versioned declared SBOM components with the same existing CTI tool. This evaluation baseline does not assert execution.','fixed_kg':True,'semantics':'No unobserved component is labelled absent, non-vulnerable or a false positive. CTI coverage is not accuracy.','full_camel_ablation':False,'expected_cti_calls':len(components)+len(linked)}
(TARGET/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
profile=json.loads((BASE/'cases/C1-r2/real-profile.json').read_text());settings=TypeAdapter(MCPConnectionSettings).validate_python(profile['sources']['vulnerability']);results=[]
for arm,items in [('with-runtime',linked),('without-runtime',components)]:
 directory=TARGET/arm;directory.mkdir()
 with MCPClient(settings,contracts=cti_contracts(),audit=RunAudit(directory/'cti-events.jsonl',arm)) as client:
  for index,component in enumerate(items,1):
   target=directory/f'component-{index:02d}';target.mkdir();obs=SoftwareObservation(package=component['name'],version=component['version'],evidence_id='sbom:'+hashlib.sha256(component['bom-ref'].encode()).hexdigest()[:24])
   row={'arm':arm,'component':component['name'],'version':component['version'],'positive_execution_link_available':(component['name'],component['version']) in observed,'status':'technical_error'}
   try:
    response=CTIVulnerabilityTool(client,target,expected_dataset_sha256=profile['sources']['cti_dataset_sha256']).lookup_vulnerabilities(obs)
    row.update(status='ok',lookup_status=response.status,vulnerabilities=[v.cve_id for v in response.vulnerabilities],identity_status=response.cti.identity_status)
   except Exception as exc:row.update(error_type=type(exc).__name__,error=str(exc)[:500])
   (target/'result.json').write_text(json.dumps(row,indent=2)+'\n');results.append(row);print(arm,component['name'],row.get('lookup_status',row['status']),flush=True)
(TARGET/'results.json').write_text(json.dumps(results,indent=2)+'\n')
