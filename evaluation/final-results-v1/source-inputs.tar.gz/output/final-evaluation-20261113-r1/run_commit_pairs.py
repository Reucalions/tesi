"""Same RankGraph via existing REST evaluate vs invoke; no new chaincode API."""
from pathlib import Path
import importlib.util,json,hashlib,shutil
from uuid import uuid4
from rest_client import Rest
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent.parent;TARGET=OUT/'commit-pairs'

def run():
 TARGET.mkdir(exist_ok=False)
 source=ROOT/'output/native-explanation-fix-20261113-r1/benchmark-collector-v2.py'
 spec=importlib.util.spec_from_file_location('existing_collector',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 shutil.copy2(ROOT/'config/scientific-graph-cases.v1.json',TARGET/'scientific-cases.json')
 trials=[];token=uuid4().hex[:10]
 for rep in range(1,4):
  for case in range(1,6):
   trials.append({'id':f'baseline-{case}-r{rep}','case':case,'repetition':rep,'evaluate_key':f'eval-estimate-{token}-{case}-{rep}','invoke_key':f'invoke-estimate-{token}-{case}-{rep}','order':['query','invoke'] if (case+rep)%2==0 else ['invoke','query']})
 protocol={'date':'2026-11-13','trials':trials,'transport':'Same authenticated REST client, channel, chaincode and RankGraph. Query uses proposal.evaluate; invoke uses endorse/submit/getStatus.','scope':'Difference estimates the additional submission/order/commit path, with timing variability. Not pure consensus CPU time or total system latency.','warmup_excluded':0,'retries':0,'native_image':module.IMAGE,'runtime_helper_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'verify_evaluate':'No derived state keys committed; input graph unchanged.','verify_invoke':'Committed native output, audit, adapted ranking and annotated graph match expected baseline results.'}
 (TARGET/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
 client=Rest();results=[]
 def call(kind,method,args,path):
  value,event=client.call(kind,'argumentation','ArgumentationContract:'+method,args)
  path.write_text(json.dumps({'event':event,'response':value},indent=2)+'\n');return value,event
 with module.baseline_runtime(TARGET):
  for trial in trials:
   directory=TARGET/trial['id'];directory.mkdir();graph=json.loads((ROOT/f"output/native-explanation-benchmark-20261113-r1/inputs/baseline-{trial['case']}-original.json").read_text())
   for kind,key in [('query',trial['evaluate_key']),('invoke',trial['invoke_key'])]:
    value,_=call('invoke','StoreGraph',[key,json.dumps(graph)],directory/('store-'+kind+'.json'));assert value['response']=={'success':'OK'}
   timings={}
   for kind in trial['order']:
    key=trial['evaluate_key'] if kind=='query' else trial['invoke_key']
    value,event=call(kind,'RankGraph',[key],directory/(kind+'.json'));assert value['response']=={'success':'OK'};timings[kind]=event['elapsed_seconds']
   for suffix in ['_rank','_annotated_graph','_native_output','_explanation_audit']:
    value,_=call('query','Get',[trial['evaluate_key']+suffix],directory/('evaluate-absence'+suffix+'.json'));assert value['response']=={'error':'NOT_FOUND'}
   value,_=call('query','Get',[trial['evaluate_key']],directory/'evaluate-input.json');assert json.loads(value['response']['success'])==graph
   actual={}
   for suffix in ['_rank','_annotated_graph','_native_output','_explanation_audit']:
    value,_=call('query','Get',[trial['invoke_key']+suffix],directory/('committed'+suffix+'.json'));actual[suffix]=json.loads(value['response']['success'])
   expected=ROOT/f"output/native-explanation-benchmark-20261113-r1/trials/baseline-{trial['case']}-original-r1"
   for suffix,name in [('_rank','collection-get_rank_result.json'),('_annotated_graph','collection-get_annotated_graph.json')]:
    raw=json.loads((expected/name).read_text());envelope=json.loads(raw['content'][0]['text']);assert actual[suffix]==json.loads(envelope['payload']['response']['success'])
   assert actual['_explanation_audit']['status']=='validated'
   row={**trial,'seconds':timings,'invoke_minus_evaluate_seconds':timings['invoke']-timings['query'],'evaluate_state_not_committed':True,'invoke_outputs_match':True};results.append(row)
   (directory/'result.json').write_text(json.dumps(row,indent=2)+'\n');print('paired',trial['id'],timings,flush=True)
 (TARGET/'results.json').write_text(json.dumps(results,indent=2)+'\n')

if __name__=='__main__':run()
