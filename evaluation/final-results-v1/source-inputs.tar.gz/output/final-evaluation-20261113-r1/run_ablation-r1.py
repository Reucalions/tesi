"""Controlled downstream comparison at the existing artifact contract boundary.

Fixed SBOM asset, KG assessment, candidates and operator policy. Runtime snapshot
and context are present/absent. No replacement agent or synthetic action profile.
"""
from pathlib import Path
import functools
import hashlib
import json
import os
import sys
import time
from uuid import uuid4

ROOT=Path('/Users/reucalion/tesi');sys.path.insert(0,str(ROOT))
from dotenv import dotenv_values
from thesis_agents.backends import RunAudit
from thesis_agents.canonical.contracts import PreparationRequest
from thesis_agents.canonical.preparation import PreparationSettings
from thesis_agents.canonical.session import PreparationSession
from thesis_agents.mcp.client import MCPClient
from thesis_agents.mcp.settings import MCPConnectionSettings
from thesis_agents.mcp.shared_client import SharedServicesClient,SharedMCPProfile
from thesis_agents.schemas.telemetry import RuntimeEvidence,SoftwareObservation
from thesis_agents.schemas.vulnerability import VulnerabilityReport
from thesis_agents.strategic.contracts import NativeRankingSettings
from thesis_agents.strategic.session import NativeStrategicSession
from thesis_agents.strategic.validation_contracts import ValidationProfile
from thesis_agents.strategic.validation_session import NativeValidationSession
from thesis_agents.strategic.selection_session import NativeSelectionSession
from thesis_agents.strategic.finalization_session import NativeFinalizationSession
from thesis_agents.tools.cti_mcp import CTIVulnerabilityTool,cti_contracts

OUT=Path(__file__).resolve().parent;BASE=ROOT/'output/case-improvements-20261106';RUN=BASE/'runs/C1-r2';ABL=OUT/'ablation';FIXED=ABL/'fixed'
def read(path):return json.loads(path.read_text())
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')

def instrumented_python(arm):
 path=ABL/arm/'python-generator';timings=ABL/arm/'generator-functions.jsonl'
 script='''#!/Users/reucalion/tesi/.venv/bin/python
import importlib.util,sys,time,json,functools
from pathlib import Path
TARGET=Path(TIMING_FILE)
runner_path=sys.argv[1];sys.argv=sys.argv[1:]
spec=importlib.util.spec_from_file_location('existing_semantic_runner',runner_path)
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
original_load=runner.load
FUNCTIONS={'bottalico_graph':('build_argumentation_graphs_from_assessment_data','graph_build_and_kg_lookup'),'bottalico_owl':('build_observed_asset_axioms','observed_asset_owl'),'bottalico_projection':('build_projection','aln_projection')}
def load(name,relative):
 module=original_load(name,relative)
 if name in FUNCTIONS:
  function,phase=FUNCTIONS[name];original=getattr(module,function)
  @functools.wraps(original)
  def timed(*args,**kwargs):
   start=time.perf_counter();ok=False
   try:result=original(*args,**kwargs);ok=True;return result
   finally:
    with TARGET.open('a') as stream:stream.write(json.dumps({'phase':phase,'elapsed_seconds':time.perf_counter()-start,'success':ok,'source':str(Path(module.__file__))})+'\\n')
  setattr(module,function,timed)
 return module
runner.load=load
raise SystemExit(runner.main())
'''.replace('TIMING_FILE',repr(str(timings)))
 path.write_text(script);path.chmod(0o755);return path


def fixed_inputs():
 FIXED.mkdir(exist_ok=False)
 sbom=read(BASE/'sources/vulnerable/sbom.cdx.json')
 components=[c for c in sbom['components'] if c.get('name')=='logback-core' and c.get('version')=='1.5.24'];assert len(components)==1
 component=components[0];identifier='sbom:'+hashlib.sha256(component['bom-ref'].encode()).hexdigest()[:24]
 observed=SoftwareObservation(package=component['name'],version=component['version'],evidence_id=identifier)
 profile=read(BASE/'cases/C1-r2/real-profile.json')
 with MCPClient(MCPConnectionSettings.model_validate(profile['sources']['vulnerability']),contracts=cti_contracts(),audit=RunAudit(FIXED/'cti-events.jsonl','fixed-sbom-inventory')) as client:
  result=CTIVulnerabilityTool(client,FIXED,expected_dataset_sha256=profile['sources']['cti_dataset_sha256']).lookup_vulnerabilities(observed)
 assert result.status=='matched' and {x.cve_id for x in result.vulnerabilities}=={'CVE-2026-1225'}
 report=VulnerabilityReport(asset_id='thesis-observed-app',lookup_status=result.status,vulnerabilities=result.vulnerabilities,cti=result.cti,package_assessment=result.package_assessment)
 write(FIXED/'software.json',observed.model_dump(mode='json'));write(FIXED/'vulnerability_report.json',report.model_dump(mode='json'))
 write(FIXED/'candidate_strategies.json',read(RUN/'sources/candidate_strategies.json'))
 write(FIXED/'inventory-proof.json',{'sbom_source':str(BASE/'sources/vulnerable/sbom.cdx.json'),'sbom_sha256':sha(BASE/'sources/vulnerable/sbom.cdx.json'),'component':component,'software':observed.model_dump(mode='json'),'interpretation':'Build inventory identity is fixed in both arms, corroborated by provided SBOM. It does not assert that every inventory component executed.'})
 return observed,report


def run():
 observed,report=fixed_inputs();runtime=read(RUN/'sources/runtime_evidence.json');request_template=read(RUN/'preparation/request.json');profile_template=read(RUN/'preparation/profile.json')
 scopes={}
 for arm in ['with-runtime','without-runtime']:
  root=ABL/arm;root.mkdir();source=root/'sources';source.mkdir()
  evidence=dict(runtime);evidence['software']=[observed.model_dump(mode='json')]
  if arm=='without-runtime':
   evidence.update(telemetry=None,endpoint_exposed=None,deserialization_observed=None,observations=['Controlled SBOM-only inventory boundary: no runtime observations or context supplied.'])
  else:evidence['observations']=evidence['observations']+['Software identity is fixed from the same SBOM inventory used in the control arm.']
  evidence=RuntimeEvidence.model_validate(evidence)
  write(source/'runtime_evidence.json',evidence.model_dump(mode='json'));write(source/'vulnerability_report.json',report.model_dump(mode='json'));write(source/'candidate_strategies.json',read(FIXED/'candidate_strategies.json'))
  req=dict(request_template);req['run_id']='eval-runtime-'+arm+'-'+uuid4().hex[:12];req['input_digests']={n:sha(source/(n+'.json')) for n in ['runtime_evidence','vulnerability_report','candidate_strategies']}
  request=PreparationRequest.model_validate(req)
  profile=dict(profile_template);profile['python']=str(instrumented_python(arm));profile=PreparationSettings.model_validate(profile)
  write(root/'request.json',request.model_dump(mode='json'));write(root/'profile.json',profile.model_dump(mode='json'))
  scopes[arm]={'run_id':request.run_id,'runtime_digest':req['input_digests']['runtime_evidence'],'report_digest':req['input_digests']['vulnerability_report'],'candidates_digest':req['input_digests']['candidate_strategies'],'timing_wrapper_sha256':sha(Path(profile.python))}
 write(ABL/'protocol.json',{'date':'2026-11-13','arms':scopes,'fixed_inventory':sha(FIXED/'software.json'),'fixed_cti':sha(FIXED/'cti_assessment.json'),'fixed_candidate_profile':sha(FIXED/'candidate_strategies.json'),'scope':'Controlled replay from the artifact boundary through existing canonical generator, real MCP ranking/validation, existing selection and real finalization; no LLM agents rerun and no claim of full CAMEL ablation.','runtime_intervention':'Remove telemetry reference/context/observations; retain exactly the same SBOM inventory, CTI report, candidates and operator policy.','repetitions_per_arm':1,'before_after_validation':'Compare rank-first proposal, native semantic status, operational status and actual post-validation recommendation. Ranking proposal is not an accepted or executed action.','generator_timing':'Thin wrappers around the three unchanged upstream functions; preserve installed file hashes, outputs and input validation. Extra function-call/clock overhead included.','product_changes':False})
 for key,value in dotenv_values(Path('/Users/reucalion/Desktop/agent-based-cti-argumentation-pipeline/mcp-fablo-server/.env')).items():
  if key in ['FABLO_USER','FABLO_PASSWORD'] and value is not None:os.environ[key]=value
 os.environ.update(FABLO_REST_URL='http://127.0.0.1:8800',FABLO_INVOKE_PATH='/invoke/{channel}/{chaincode}',FABLO_QUERY_PATH='/query/{channel}/{chaincode}')
 shared=SharedMCPProfile.load(ROOT/'output/real-cases-20261105-r1/mcp-profile.json')
 summaries=[]
 for arm in scopes:
  root=ABL/arm;started=time.perf_counter()
  session=PreparationSession(root/'sources',root/'preparation',PreparationRequest.model_validate(read(root/'request.json')),PreparationSettings.model_validate(read(root/'profile.json')))
  print('preparation started',arm,flush=True);session.prepare_argumentation();session.assert_complete();print('preparation complete',arm,flush=True)
  with SharedServicesClient(shared,audit=RunAudit(root/'shared-mcp-events.jsonl',scopes[arm]['run_id']),stderr_path=root/'bridge.stderr.log',finalization=True) as client:
   ranking=NativeStrategicSession(root/'preparation',root/'ranking',NativeRankingSettings.model_validate(read(RUN/'strategic/ranking-profile.json')),client)
   while op:=ranking.next_operation():getattr(ranking,op['tool'])(**{k:v for k,v in op.items() if k!='tool'})
   rank=ranking.assert_complete()
   vp=read(RUN/'validation/validation-profile.json');vp.update(run_id=scopes[arm]['run_id'],ranking_sha256=sha(root/'ranking/native_strategic_ranking.json'))
   validation=NativeValidationSession(root/'ranking',root/'validation',ValidationProfile.model_validate(vp),client)
   while op:=validation.next_operation():getattr(validation,op['tool'])(**{k:v for k,v in op.items() if k!='tool'})
   valid=validation.assert_complete()
   selection=NativeSelectionSession(root/'validation',root/'recommendation');selection.publish_native_recommendation();recommendation=selection.assert_complete()
   final=NativeFinalizationSession(root/'recommendation',root/'finalization',client)
   while op:=final.next_operation():getattr(final,op['tool'])(**{k:v for k,v in op.items() if k!='tool'})
   finalized=final.assert_complete()
  item={'arm':arm,'elapsed_seconds':time.perf_counter()-started,'run_id':scopes[arm]['run_id'],'ranking':rank.model_dump(mode='json',by_alias=True),'validation':valid.model_dump(mode='json',by_alias=True),'recommendation':recommendation.model_dump(mode='json',by_alias=True),'finalization':finalized.model_dump(mode='json',by_alias=True)}
  write(root/'summary.json',item);summaries.append(item);print('arm finalized',arm,flush=True)
 write(ABL/'results.json',summaries)

if __name__=='__main__':run()
